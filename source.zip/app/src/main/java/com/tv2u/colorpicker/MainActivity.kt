package com.tv2u.colorpicker

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ImageView
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup

class MainActivity : Activity() {
 private val overlayRequest = 10
 private val captureRequest = 11
 private lateinit var projectionManager: MediaProjectionManager
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
  val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,48,32,32); gravity = Gravity.CENTER_HORIZONTAL; setBackgroundColor(Color.rgb(245,247,250)) }
  layout.addView(ImageView(this).apply { setImageResource(R.drawable.tv2u_logo); scaleType = ImageView.ScaleType.FIT_CENTER }, LinearLayout.LayoutParams(-1, 100))
  layout.addView(TextView(this).apply { text = "color-picker"; textSize = 25f; setTextColor(Color.rgb(25,36,48)); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, 100))
  layout.addView(TextView(this).apply { text = "Small circular floating picker • HEX only • Tap HEX to copy\n\nCapture permission is required by Android. The app works offline."; textSize = 16f; gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, 170))
  layout.addView(Button(this).apply { text = "Start floating picker"; setOnClickListener { startPicker() } }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
  layout.addView(Button(this).apply { text = "Stop picker"; setOnClickListener { stopService(Intent(this@MainActivity, PickerService::class.java)) } }, LinearLayout.LayoutParams(-1,-2))
  setContentView(layout)
 }
 private fun startPicker() {
  if (!Settings.canDrawOverlays(this)) { startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), overlayRequest); return }
  startActivityForResult(projectionManager.createScreenCaptureIntent(), captureRequest)
 }
 override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
  super.onActivityResult(requestCode,resultCode,data)
  if (requestCode == overlayRequest && Settings.canDrawOverlays(this)) startPicker()
  if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
   val service = Intent(this, PickerService::class.java).putExtra("resultCode", resultCode).putExtra("resultData", data)
   startForegroundService(service)
   moveTaskToBack(true)
  }
 }
}
