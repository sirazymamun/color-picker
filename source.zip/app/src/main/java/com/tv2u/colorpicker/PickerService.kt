package com.tv2u.colorpicker

import android.app.*
import android.content.*
import android.graphics.*
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.*
import java.nio.ByteBuffer
import kotlin.math.*

class PickerService : Service() {
 private lateinit var wm: WindowManager
 private var bubble: TextView? = null
 private var bubbleParams: WindowManager.LayoutParams? = null
 private var panel: LinearLayout? = null
 private var projection: MediaProjection? = null
 private var reader: ImageReader? = null
 private var virtualDisplay: android.hardware.display.VirtualDisplay? = null
 private var lastColor = Color.WHITE
 private var lastFrameValid = false
 private var sampleCount = 0
 private var width = 0
 private var height = 0
 private var density = 0
 private val handler = Handler(Looper.getMainLooper())
 private var sampling = false
 private var sampleX = 0
 private var sampleY = 0
 private var captureAfter = 0L
 private var captureTimeout: Runnable? = null
 override fun onBind(intent: Intent?) : IBinder? = null
 override fun onCreate() { super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager }
 override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
  if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
  if (projection != null) return START_STICKY
  val channelId = "picker"
  val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
  manager.createNotificationChannel(NotificationChannel(channelId,"Color picker",NotificationManager.IMPORTANCE_LOW))
  val stopIntent = PendingIntent.getService(this, 1, Intent(this, PickerService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
  val notification = Notification.Builder(this,channelId).setContentTitle("color-picker").setContentText("Floating picker is active").setSmallIcon(android.R.drawable.ic_menu_edit).addAction(Notification.Action.Builder(null,"Stop",stopIntent).build()).build()
  startForeground(1,notification)
  val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("resultData", Intent::class.java) else intent?.getParcelableExtra<Intent>("resultData")
  if (data == null) { stopSelf(); return START_NOT_STICKY }
  val metrics = resources.displayMetrics
  val bounds = wm.currentWindowMetrics.bounds
  width = bounds.width(); height = bounds.height(); density = metrics.densityDpi
  val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
  try {
   projection = mgr.getMediaProjection((intent?.getIntExtra("resultCode",Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED), data)
   projection?.registerCallback(object: MediaProjection.Callback() { override fun onStop() { handler.post { stopSelf() } } },handler)
   reader = ImageReader.newInstance(width,height,android.graphics.PixelFormat.RGBA_8888,3)
   // Drain frames continuously so sampling never stalls on an old buffer.
   reader?.setOnImageAvailableListener({ r ->
    val image = try { r.acquireLatestImage() } catch (_: Exception) { null }
    if (image != null) {
     if (sampling && SystemClock.uptimeMillis() >= captureAfter) {
      val success = sampleImage(image,sampleX,sampleY)
      if (success) handler.post { finishSample(true) }
     }
     image.close()
    }
   },handler)
   virtualDisplay = projection?.createVirtualDisplay("Picker",width,height,density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,handler)
   showBubble()
  } catch (e: Exception) { stopSelf() }
  return START_STICKY
 }
 private fun params(w:Int,h:Int,x:Int,y:Int) = WindowManager.LayoutParams(w,h,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,android.graphics.PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.LEFT; this.x=x; this.y=y }
 private fun dp(n:Int) = (n * resources.displayMetrics.density).toInt()
 private fun showBubble() {
  val b = TextView(this).apply { text = "◎"; textSize=25f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); background = circle(Color.rgb(38,119,212)); elevation=dp(6).toFloat() }
  val p = params(dp(42),dp(42),dp(24),height/3)
  wm.addView(b,p); bubble=b; bubbleParams=p
  var downX=0f; var downY=0f; var baseX=0; var baseY=0; var moved=false
  b.setOnTouchListener { _, event ->
   when(event.actionMasked) {
    MotionEvent.ACTION_DOWN -> { downX=event.rawX;downY=event.rawY;baseX=p.x;baseY=p.y;moved=false;true }
    MotionEvent.ACTION_MOVE -> { if (abs(event.rawX-downX)>dp(4) || abs(event.rawY-downY)>dp(4)) moved=true; p.x=(baseX+event.rawX-downX).toInt().coerceIn(-dp(21),width-dp(21));p.y=(baseY+event.rawY-downY).toInt().coerceIn(-dp(21),height-dp(21));wm.updateViewLayout(b,p); true }
    MotionEvent.ACTION_UP -> {
     if (!sampling) {
      sampling = true
      panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel = null
      // Overlay must be fully removed from the compositor before capturing.
      b.visibility = View.INVISIBLE
      sampleX = (p.x + dp(21)).coerceIn(0,width-1)
      sampleY = (p.y + dp(21)).coerceIn(0,height-1)
      sampleCount = 0
      captureAfter = SystemClock.uptimeMillis() + 550L
      captureTimeout = Runnable { if (sampling) finishSample(false) }
      handler.postDelayed(captureTimeout!!,4000L)
     }
     true
    }
    else -> true
   }
  }
 }
 private fun circle(color:Int) = android.graphics.drawable.GradientDrawable().apply { shape=android.graphics.drawable.GradientDrawable.OVAL;setColor(color);setStroke(dp(2),Color.WHITE) }
 private fun sampleImage(img: android.media.Image,x:Int,y:Int): Boolean {
  return try {
   val plane = img.planes[0]
   val px = (x.toLong() * img.width / width.coerceAtLeast(1)).toInt().coerceIn(0,img.width-1)
   val py = (y.toLong() * img.height / height.coerceAtLeast(1)).toInt().coerceIn(0,img.height-1)
   val offset = py*plane.rowStride + px*plane.pixelStride
   val buf = plane.buffer
   if (offset + 2 >= buf.limit()) false else {
    val r=buf.get(offset).toInt() and 255
    val g=buf.get(offset+1).toInt() and 255
    val b=buf.get(offset+2).toInt() and 255
    // A black pixel is legitimate; do not substitute a previous color.
    lastColor=Color.rgb(r,g,b)
    sampleCount++
    true
   }
  } catch (_: Exception) { false }
 }
 private fun finishSample(success:Boolean) {
  if (!sampling) return
  sampling=false
  captureTimeout?.let { handler.removeCallbacks(it) }; captureTimeout=null
  bubble?.visibility=View.VISIBLE
  if (success) showPanel() else Toast.makeText(this,"Screen capture unavailable. Open color-picker and restart capture.",Toast.LENGTH_LONG).show()
 }
 private fun showPanel() {
  panel?.let { wm.removeView(it) }
  val hex=String.format("#%06X",0xFFFFFF and lastColor)
  val layout=LinearLayout(this).apply {
   orientation=LinearLayout.HORIZONTAL
   gravity=Gravity.CENTER_VERTICAL
   setPadding(dp(12),dp(10),dp(12),dp(10))
   background=android.graphics.drawable.GradientDrawable().apply {
    setColor(Color.WHITE);cornerRadius=dp(14).toFloat();setStroke(dp(1),Color.LTGRAY)
   }
   elevation=dp(8).toFloat()
  }
  val swatch=TextView(this).apply {
   text="●";textSize=22f;setTextColor(lastColor)
  }
  layout.addView(swatch)
  val code=TextView(this).apply {
   text=hex;textSize=19f;setTextColor(Color.rgb(25,36,48))
   setPadding(dp(9),dp(4),dp(9),dp(4))
   setOnClickListener { copy(hex) }
  }
  layout.addView(code)
  val close=TextView(this).apply {
   text="×";textSize=22f;setTextColor(Color.DKGRAY)
   setPadding(dp(8),0,0,0)
   setOnClickListener { panel?.let { wm.removeView(it) };panel=null }
  }
  layout.addView(close)
  val p=bubbleParams ?: return
  val panelParams=params(dp(185),-2,(p.x-dp(70)).coerceIn(0,(width-dp(185)).coerceAtLeast(0)),(p.y+dp(50)).coerceIn(0,(height-dp(90)).coerceAtLeast(0)))
  wm.addView(layout,panelParams);panel=layout
  getSharedPreferences("history",MODE_PRIVATE).edit().putString("latest",hex).apply()
 }
 private fun copy(s:String) { (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(ClipData.newPlainText("Color",s));Toast.makeText(this,"Copied!",Toast.LENGTH_SHORT).show() }
 override fun onDestroy() { sampling=false;captureTimeout?.let { handler.removeCallbacks(it) };reader?.setOnImageAvailableListener(null,null);panel?.let { try { wm.removeView(it) } catch (_:Exception){} };bubble?.let { try { wm.removeView(it) } catch (_:Exception){} };virtualDisplay?.release();reader?.close();projection?.stop();super.onDestroy() }
}
