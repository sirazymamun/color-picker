plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
 namespace = "com.tv2u.colorpicker"
 compileSdk = 35
 defaultConfig { applicationId = "com.tv2u.colorpicker"; minSdk = 26; targetSdk = 34; versionCode = 8; versionName = "1.0.7" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
